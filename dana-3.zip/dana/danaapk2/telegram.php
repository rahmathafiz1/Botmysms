<?php
$id_telegram = "6047192870";
$id_botTele  = "5875037216:AAHRvgzZ_rNKJGfrpFZOyamsfaVdGzs-ht8";
?>
